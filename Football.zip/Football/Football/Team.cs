﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football
{
    public class Team
    {
        private Coach coach { get; set; }
        private List<FootballPlayer> players { get; set; }
        private bool allPlayers = false;

        public Team(Coach coach)
        {
            this.coach = coach;
            players = new List<FootballPlayer>();
        }

        public void AddPlayer(FootballPlayer player)
        {

            if (players.Count >= 22)
            {
                Console.WriteLine("Не можете да добавите повече играчи!");
                return;
            }

            players.Add(player);

            if (players.Count < 11)
            {
                Console.WriteLine("Няма достатъно играчи!");
                return;
            }

            allPlayers = true;
        }

        public void FindAverageAge()
        {
            if (allPlayers)
            {
                double averageAge = 0;
                foreach (FootballPlayer player in players)
                {
                    averageAge += player.Age;
                }
                Console.WriteLine($"Average age of team is {0}", averageAge);
            }
            else
            {
                Console.WriteLine("There are not enough players in the team. Please add more!");
            }
        }
    }
}
