﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football
{
    public class Game
    {
        
        public Team Team1 { get; set; }
        public Team Team2 { get; set; }
        public Referee Referee { get; set; }
        private List<Referee> AssistantReferees { get; set; }
        public List<Goal> Goals { get; set; }
        public string Result { get; private set; }
        public Team Winner { get; private set; }

        private int goal1 = 0;
        private int goal2 = 0;

        public Game(Team team1, Team team2, Referee referee, List<Referee> assistantReferees)
        {
            Team1 = team1;
            Team2 = team2;
            Referee = referee;
            
            if (assistantReferees.Count != 0)
            {
                throw new ArgumentException("Само двама асистенти могат да участват");
            }

           AssistantReferees = assistantReferees;
        }

        public void addGoal(Goal goals, string team)
        {
            Goals.Add(goals);
            if (team == "Отбор 1")
            {
                goal1++;
            }

            if (team == "Отбор 2")
            {
                goal2++;
            }

            Result = $"Отбор 1 " + goal1 + " - " + goal2 + " Отбор 2";
        }

        public void DetermineWinner()
        {
            if (goal1 > goal2)
            {
                Console.WriteLine("Отбор 1 печели!");
            }
            else
            {
                Console.WriteLine("Отбор 2 печели!");
            }
        }

    }
}
